function redirigir(url) {
    openInNewTab(url);
}
function openInNewTab(url) {
    window.open(url, '_blank');
}
document.addEventListener("DOMContentLoaded", function() {
    const slider = document.querySelector(".slider");
    const slides = document.querySelectorAll(".slide");
    const btnAntes = document.querySelector(".botonAntes");
    const btnDespues = document.querySelector(".botonDespues");
    const slideWidth = slides[0].clientWidth;
    let currentIndex = 0;
    const intervalTime = 3000;
    let slideInterval;

    function startSlide() {
        slideInterval = setInterval(SigSlide, intervalTime);
      }

    function pauseSlide() {
        clearInterval(slideInterval);
    }

    function VeHastaSlide(index) {
        slider.style.transform = `translateX(-${slideWidth * index}px)`;
        currentIndex = index;
      }
    function SigSlide() {
        if (currentIndex < slides.length - 1) {
            currentIndex++;
        } else {
            currentIndex = 0;
        }
        VeHastaSlide(currentIndex);
    }
    function AntSlide() {
        if (currentIndex > 0) {
          currentIndex--;
        } else {
          currentIndex = slides.length - 1;
        }
        VeHastaSlide(currentIndex);
    }
    btnDespues.addEventListener("click", function() {
        SigSlide();
        pauseSlide();
        startSlide();
    });      
    btnAntes.addEventListener("click", function() {
        AntSlide();
        pauseSlide();
        startSlide();
    });     
    startSlide();
});

document.addEventListener("DOMContentLoaded", function() {
    let counterValue = localStorage.getItem("visits") || 0;
    counterValue++;
    localStorage.setItem("visits", counterValue);
    document.querySelector(".counter").innerText = counterValue;
});

const fechaActual = document.querySelector(".fechaAct"); 
etiquetaDias  = document.querySelector(".dias"); 
antSigIcono = document.querySelectorAll(".items span"); 

let fecha = new Date(); 
anyoActual = fecha.getFullYear();
mesActual = fecha.getMonth(); 

const meses = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]

const crearCalendario = () => {
    let primerDiaDelMes = new Date(anyoActual, mesActual , 1).getDay(); 
     ultimaFechaDelMes = new Date(anyoActual, mesActual + 1, 0).getDate(); 
     ultimoDiaDelMes = new Date(anyoActual, mesActual, ultimaFechaDelMes).getDay(); 
     ultimaFechaDelUltimoMes = new Date(anyoActual, mesActual, 0).getDate(); 
     primerDiaDelMes = (primerDiaDelMes === 0) ? 6 : primerDiaDelMes - 1; 
    let etiquetaLi = ""

    for (let i = primerDiaDelMes; i>0; i--){ 
        etiquetaLi += `<li class="inactivos">${ultimaFechaDelUltimoMes - i + 1}</li>`
    }

    for (let i = 1; i <= ultimaFechaDelMes; i++) { 
        let esHoy = i === fecha.getDate() && mesActual === new Date().getMonth() && anyoActual === new Date().getFullYear() ? "activos" : ""; 
        let specialDateClass = i === 31 && mesActual === 4 && anyoActual === 2024 ? "fecha-especial" : ""; 
        etiquetaLi += `<li class="${esHoy} ${specialDateClass}" data-day="${i}">${i}</li>`;
    }

    for (let i = ultimoDiaDelMes; i < 7; i++){ 
        etiquetaLi += `<li class="inactivos">${ i - ultimoDiaDelMes + 1}</li>`
    }

    fechaActual.innerText = `${meses[mesActual]} ${anyoActual}` 
    etiquetaDias.innerHTML = etiquetaLi;

    
    document.querySelectorAll('.fecha-especial').forEach(dia => {
        dia.addEventListener('click', () => {
            alert('Entrega del Calendario de Lenguaje de Marcas'); 
        });
    });
} 
crearCalendario();


antSigIcono.forEach(icon => {
    icon.addEventListener("click", () => {
        mesActual = icon.id === "botonAntes" ? mesActual - 1 : mesActual + 1;

        if(mesActual< 0 || mesActual > 11){
            fecha = new Date(anyoActual, mesActual);
            anyoActual = fecha.getFullYear();
            mesActual = fecha.getMonth();
        }else{
            fecha = new Date();
        }

        crearCalendario();
    })
});

document.addEventListener('DOMContentLoaded', function() {
    var dropdown = document.querySelector('.menu-item.dropdown');
    var toggle = dropdown.querySelector('.otros');

    toggle.addEventListener('click', function() {
        dropdown.classList.toggle('show');
    });
});

document.addEventListener('DOMContentLoaded', function() {
    var iframes = document.querySelectorAll('.paginas iframe');

    iframes.forEach(function(iframe) {
        iframe.addEventListener('click', function() {
            var src = iframe.getAttribute('src');
            if (src) {
                window.location.href = src;
            }
        });
    });
});