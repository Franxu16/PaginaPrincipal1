function mostrarPopup(){
    alert("GP de Austria, L71/71 Lando Norris VR 1:07:475");
}
window.onload = function(){
    mostrarPopup();
};
 
//Las funciones que están encima son las que controlan el mensaje popup que sale al entrar a la página